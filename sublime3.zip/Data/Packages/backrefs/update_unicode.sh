python3.3 tools/unidatadownload.py
python3.3 tools/unipropgen.py st3/backrefs/uniprops/unidata
